# Golden Fortune — Android
Полный исходный проект для сборки APK на GitHub Actions.

1. Загрузите **содержимое** этой папки в корень репозитория GitHub.
2. Откройте **Actions → Build Golden Fortune APK → Run workflow**.
3. После успешной сборки скачайте **Golden-Fortune-APK** и извлеките `app-debug.apk`.

Сборка создаёт APK с отладочной подписью. Для публикации в Google Play потребуется release-подпись и дополнительные проверки.
Игра работает офлайн, с виртуальными монетами.
