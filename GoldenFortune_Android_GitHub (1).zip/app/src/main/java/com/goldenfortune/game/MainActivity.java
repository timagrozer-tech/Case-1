package com.goldenfortune.game;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
public class MainActivity extends Activity {
 private WebView browser;
 @Override public void onCreate(Bundle b) {
  super.onCreate(b);
  browser=new WebView(this);
  browser.setWebViewClient(new WebViewClient());
  WebSettings s=browser.getSettings();
  s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);s.setAllowFileAccess(true);
  setContentView(browser);
  browser.loadUrl("file:///android_asset/www/index.html");
 }
 @Override public void onBackPressed() {if(browser.canGoBack())browser.goBack();else super.onBackPressed();}
 @Override protected void onDestroy(){browser.destroy();super.onDestroy();}
}
